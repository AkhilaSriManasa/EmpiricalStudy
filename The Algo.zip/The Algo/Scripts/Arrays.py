arr = [10, 20, 30, 40]
arr[1] = 30
print(arr)
