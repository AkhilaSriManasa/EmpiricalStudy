PROJECT
"z = merge_two_dicts(x, y)
"
PROJECT
"def merge_two_dicts(x, y):
    z = x.copy()   # start with x's keys and values
    z.update(y)    # modifies z with y's keys and values & returns None
    return z
"
