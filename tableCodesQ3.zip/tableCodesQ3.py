PROJECT
"print(""This code executes before main."") 

def functionA():
    print(""Function A"")

def functionB():
    print(""Function B"")

if __name__ == '__main__':
    functionA()
    functionB()
"
